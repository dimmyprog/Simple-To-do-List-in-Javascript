    // Declarations of changing variable
    var todoText = document.getElementById('todotext');
    var todoDate = document.getElementById('tododate');
    var todoTime = document.getElementById('todotime');
    var todoOrder = document.getElementById('todoorder');
    var currentIndex;

    //const taskRequired = new Audio("sounds/recklesslove.mp3");
    //taskRequired.play();

//Every event listener
function borders(){
    todoText.style.border = "none";
}

// This little guy calls the great todolist
displaydata(); 


// Code block that answers submit
function submitform(){
    adddata();
    
}


// Code block that answers update
function updateform(value){
    var newValue = value;
    updatedata();
    cleardata();
}


// Code block to add new todo to the list of all todoliast available
function adddata(){

    if(todoText.value === ""){
        const taskRequired = new Audio("sounds/taskrequired.mp3");
        taskRequired.play();
        function codeTimeOut(){
            var dataTodoText = document.getElementById('todotext');   
                dataTodoText.style.border = "3px solid pink"
             
        }

        var inter = setInterval(codeTimeOut, 10);

        setTimeout(function(){
            clearInterval(inter);
        }, 10);
       
        
    }else{
       
        var data = 
    {
        tdText : todoText.value,
        tdTime: todoTime.value,
        tdDate: todoDate.value,
        tdOrder: todoOrder.value,
        tdStatus: "bg-primary",
        tdStatusData: "Pending Task"
    }

    let dataArray;
   
    if(localStorage.getItem("mytodolist") === null){
        dataArray = [];
    }else{
        dataArray = JSON.parse(localStorage.getItem("mytodolist"));
    }
   
    dataArray.push(data);
    localStorage.setItem("mytodolist", JSON.stringify(dataArray));
    
    cleardata();
    }
    
}


// Code block to show all todo list
function displaydata(){
     
    var todolist = [];
    todolist = JSON.parse(localStorage.getItem("mytodolist"));
    todolist.sort(function(a, b){
       return a.tdOrder -  b.tdOrder;
    });
    var card = '';
    for(i = 0; i <= todolist.length; i++){
     card += 
     `<div class="col-12 col-sm-4 col-lg-3" >
        <div class="card single-product-card" >
        <input type="hidden" name="c-Text" id="c-Text" value="${todolist[i].tdText}">
        <input type="hidden" name="c-Date" id="c-Date" value="${todolist[i].tdDate}">
        <input type="hidden" name="c-Time" id="c-Time" value="${todolist[i].tdTime}">
        <input type="hidden" name="c-Order" id="c-Order" value="${todolist[i].tdOrder}">
                <div class="pager">
                <div class="pager1" onclick="updatedata(${i}, '${todolist[i].tdText}', '${todolist[i].tdDate}', '${todolist[i].tdTime}', '${todolist[i].tdOrder}')">
                <!-- Product Title--><a class="product-title d-block " href="#">${todolist[i].tdText}&nbsp;&nbsp;&nbsp;&nbsp;  <span id="tdOrderClass"></span></a>
                <!-- Product Price-->
                <p class="sale-prices">${todolist[i].tdDate} &nbsp;&nbsp; ${todolist[i].tdTime}</p>
                </div>
                <div class="pager2">
                <p>
                    <a class="btn btn-success btn" onclick="completetodo(${i})">Complete Task</a>&nbsp;
                    <a class="btn btn-primary btn" onclick="deletetodo(${i})">Delete Task</a>
                </p> 
                </div>
                </div>
         </div>
      </div> `

         document.getElementById('screen').innerHTML = card;
        
    }
}


// Code block to update a todo list
function updatedata(Tid, Ttext, Tdate, Ttime, Torder){
    var tempDataArray = [];
    var tempData = 
    {
        tempDataid: Tid,
        tempDatatext: Ttext,
        tempDatadate: Tdate,
        tempDatatime: Ttime,
        tempDataorder: Torder
    }
    tempDataArray.push(tempData);
    localStorage.setItem('todotempdata', JSON.stringify(tempData));
    window.location.href = "updatetodo.html";
    
}


// Code block to resest the page 
function cleardata(){
    window.location.href = "index.html";
}


// Code block to complete  a todolist and move the todolist into the recycle bin 
function completetodo(value){
   
   var completeId = value;

   var data = 
   {
       tdText : document.getElementById('c-Text').value,
       tdTime: document.getElementById('c-Time').value,
       tdDate: document.getElementById('c-Date').value,
       tdOrder: document.getElementById('c-Order').value,
       tdStatus: "bg-primary",
       tdStatusData: "Completed Task"
   }

   let dataArray;
  
   if(localStorage.getItem("completedtodolist") === null){
       dataArray = [];
   }else{
       dataArray = JSON.parse(localStorage.getItem("completedtodolist"));
   }

   dataArray.push(data);
   localStorage.setItem("completedtodolist", JSON.stringify(dataArray));
   deletetodo(completeId);
}

// Code block to delete a todolist completely from the database
function deletetodo(value){
    
    var dataArray;
   
   if(localStorage.getItem("mytodolist") === null){
    dataArray = [];
    }else{
        dataArray = JSON.parse(localStorage.getItem("mytodolist"));
    }


    dataArray.splice(value, 1);

    localStorage.setItem('mytodolist', JSON.stringify(dataArray));
    cleardata();    
}






